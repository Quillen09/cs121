package week11.bigOActivity;

public class bigOTest {
    public static void main(String[] args) {
        bigO once = new bigO();
        bigO N = new bigO();
        bigO NX2 = new bigO();
        once.printOnce("printed one time");
        N.printNTimes();
        NX2.printNX2Times();

    }
}
