package week11.recursionActivity;

public class recursionTest {
    public static void main(String[] args) {
      recursion num = new recursion();
      recursion alpha = new recursion();
        System.out.println(alpha.alphaBackwards('z'));
        System.out.println(num.countDown(10));
    }
}
