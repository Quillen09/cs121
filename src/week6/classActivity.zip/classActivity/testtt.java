package week6.classActivity;

public class testtt {
    public static void main(String[] args) {
        characters character1 = new characters("name1", "move1");
        characters character2 = new characters("name2", "move2");
        character1.displayInfo();
        character2.displayInfo();


        otherCharacters character3 = new otherCharacters(15, 30);
        otherCharacters character4 = new otherCharacters(20, 15);
        character3.showInfo();
        character4.showInfo();
    }
}
