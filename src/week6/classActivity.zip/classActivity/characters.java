package week6.classActivity;

public class characters {
    String name, moveName;
    int damage, hitPoint;

    characters(String name, String moveName) {
        this.name = name;
        this.moveName = moveName;
    }
    public void displayInfo(){
        System.out.printf("This is character name: %s%n This is character move: %s%n", name, moveName);
    }

}
